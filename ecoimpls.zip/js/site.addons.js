	if(window.innerWidth < 770){
		$("#nav ul li a").one("click", false);
	};